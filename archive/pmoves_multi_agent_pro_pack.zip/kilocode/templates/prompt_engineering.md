# PMOVES Prompt Engineering Notes
- State goal, input data, constraints, and required **output format** (JSON/Markdown).
- Ask for **assumptions & unknowns** before irreversible steps.
- Prefer **tool-using plans** (Docling → Postman → E2B → VL Sentinel).