# PMOVES Large Projects Playbook
- Break down into **modes** (Docling/Executor/Runner/Sentinel).
- Keep a **task ledger** and checkpoint artifacts after each phase.
- Cache partial results; verify with VL Sentinel before finalizing.