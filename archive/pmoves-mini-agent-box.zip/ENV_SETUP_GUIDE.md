# Env setup (portable, no-bake)
Use the helper scripts to create/merge `.env` by pasting secrets or scanning folders for `keys.info` / `.env` files. Backups are created automatically.