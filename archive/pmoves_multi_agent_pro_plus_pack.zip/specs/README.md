Put your `openapi.json` or `openapi.yaml` here for the nightly regression.
The workflow will first try `specs/openapi.json` then fallback to `specs/openapi.yaml`.